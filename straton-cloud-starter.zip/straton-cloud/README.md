
# Stratón Cloud Command Node

## Setup

1. Copy `.env.example` to `.env` and add your API keys.
2. Install requirements: `pip install -r requirements.txt`
3. Run locally: `uvicorn main:app --reload`
